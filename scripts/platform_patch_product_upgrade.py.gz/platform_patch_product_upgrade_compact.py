from pathlib import Path

app_path = Path('src/App.tsx')
css_path = Path('src/style.css')
app = app_path.read_text(encoding='utf-8')
css = css_path.read_text(encoding='utf-8')
if 'FJ PERSONAL CONTEST TOOLS v1' in app or 'FJ PERSONAL CONTEST TOOLS v1' in css:
    raise SystemExit('Personal contest tools already exist.')

def rep(source, old, new, label):
    if source.count(old) != 1:
        raise SystemExit(f'{label}: expected one match, found {source.count(old)}')
    return source.replace(old, new, 1)

app = rep(app, '  CalendarDays, Menu, Search, Trophy,\n',
          '  CalendarDays, Menu, Search, Trophy, Bookmark, BookmarkCheck, CalendarPlus,\n', 'icons')
helper = r'''function downloadContestCalendar(exam: Exam): boolean {
  const start = new Date(exam.starts_at)
  const end = examEnd(exam)
  if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) return false
  const esc = (s: string) => s.replace(/\\/g, '\\\\').replace(/\r?\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;')
  const stamp = (d: Date) => d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z')
  const desc = [exam.description || 'مسابقهٔ علمی در فارسی جاج', `زمان شروع: ${dateText(exam.starts_at)}`, `مدت مسابقه: ${fa(exam.duration_minutes)} دقیقه`].join('\n')
  const lines = ['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//FarsiJudge//Contest Calendar//FA','CALSCALE:GREGORIAN','METHOD:PUBLISH','BEGIN:VEVENT',
    `UID:${exam.id.replace(/[^a-zA-Z0-9_-]/g, '')}@farsijudge`, `DTSTAMP:${stamp(new Date())}`, `DTSTART:${stamp(start)}`, `DTEND:${stamp(end)}`,
    `SUMMARY:${esc(exam.title)}`, `DESCRIPTION:${esc(desc)}`, `URL:${window.location.origin}${window.location.pathname}`,
    'BEGIN:VALARM','TRIGGER:-PT15M','ACTION:DISPLAY',`DESCRIPTION:${esc(`مسابقهٔ ${exam.title} تا ۱۵ دقیقهٔ دیگر آغاز می‌شود.`)}`,'END:VALARM','END:VEVENT','END:VCALENDAR']
  const url = URL.createObjectURL(new Blob([lines.join('\r\n') + '\r\n'], { type: 'text/calendar;charset=utf-8' }))
  const a = document.createElement('a')
  a.href = url
  a.download = `farsijudge-${exam.id.slice(0, 8)}.ics`
  document.body.appendChild(a); a.click(); a.remove()
  window.setTimeout(() => URL.revokeObjectURL(url), 1500)
  return true
}

'''
app = rep(app, 'const durationText = (seconds: number) => {', helper + 'const durationText = (seconds: number) => {', 'calendar helper')
app = rep(app, '  const [exams, setExams] = useState<Exam[]>([])\n', '''  const [exams, setExams] = useState<Exam[]>([])
  const [savedContestIds, setSavedContestIds] = useState<string[]>(() => {
    try { const ids = JSON.parse(localStorage.getItem('farsijudge-saved-contests') || '[]'); return Array.isArray(ids) ? ids.filter((id): id is string => typeof id === 'string') : [] }
    catch { return [] }
  })
''', 'saved state')
app = rep(app, '  const userId = session?.user.id ?? (demoMode ? demoUser.id : null)\n', '''  useEffect(() => {
    try { localStorage.setItem('farsijudge-saved-contests', JSON.stringify(savedContestIds)) }
    catch { /* Browser storage can be unavailable. */ }
  }, [savedContestIds])

  const userId = session?.user.id ?? (demoMode ? demoUser.id : null)
''', 'save watchlist')
app = rep(app, '  const enterDemo = () => {\n', '''  const toggleSavedContest = (id: string) => setSavedContestIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id])
  const addContestToCalendar = (exam: Exam) => {
    if (!downloadContestCalendar(exam)) return notify('زمان مسابقه معتبر نیست.', 'error')
    notify('فایل تقویم با یادآور ۱۵ دقیقه‌ای آماده شد.', 'success')
  }

  const enterDemo = () => {
''', 'utility handlers')

# Public directory props, state and filters.
app = rep(app, 'function WelcomePage({ theme, onToggleTheme, onLogin, onRegister, onDemo, showDemo, exams, now, onReviewQuestions, onLeaderboard }: {',
          'function WelcomePage({ theme, onToggleTheme, onLogin, onRegister, onDemo, showDemo, exams, now, onReviewQuestions, onLeaderboard, savedContestIds, onToggleSaved, onAddToCalendar }: {', 'welcome props')
app = rep(app, '  onRegister: () => void; onDemo: () => void; showDemo: boolean; exams: Exam[]; now: number\n  onReviewQuestions: (exam: Exam) => void; onLeaderboard: (exam: Exam) => void\n}) {',
          '  onRegister: () => void; onDemo: () => void; showDemo: boolean; exams: Exam[]; now: number\n  onReviewQuestions: (exam: Exam) => void; onLeaderboard: (exam: Exam) => void\n  savedContestIds: string[]; onToggleSaved: (id: string) => void; onAddToCalendar: (exam: Exam) => void\n}) {', 'welcome prop types')
app = rep(app, "  const [filter, setFilter] = useState<'all' | 'upcoming' | 'active' | 'ended'>('all')\n",
          "  const [filter, setFilter] = useState<'all' | 'upcoming' | 'active' | 'ended' | 'saved'>('all')\n", 'welcome filter')
app = rep(app, "  const ended = publicExams.filter((exam) => getStatus(exam, now) === 'ended')\n  const next = upcoming[0]\n  const visible = (filter === 'upcoming' ? upcoming : filter === 'active' ? active : filter === 'ended' ? ended : publicExams)\n",
          "  const ended = publicExams.filter((exam) => getStatus(exam, now) === 'ended')\n  const savedSet = new Set(savedContestIds)\n  const saved = publicExams.filter((exam) => savedSet.has(exam.id))\n  const next = upcoming[0]\n  const visible = (filter === 'saved' ? saved : filter === 'upcoming' ? upcoming : filter === 'active' ? active : filter === 'ended' ? ended : publicExams)\n", 'welcome data')
app = rep(app, "{([['all','همه'],['upcoming','پیش‌رو'],['active','فعال'],['ended','پایان‌یافته']] as const).map(([value,label]) => <button key={value} className={filter === value ? 'active' : ''} onClick={() => setFilter(value)}>{label}</button>)}",
          "{([['all','همه'],['upcoming','پیش‌رو'],['active','فعال'],['ended','پایان‌یافته'],['saved','ذخیره‌شده‌ها']] as const).map(([value,label]) => <button key={value} className={filter === value ? 'active' : ''} onClick={() => setFilter(value)}>{label}{value === 'saved' ? ` (${fa(saved.length)})` : ''}</button>)}", 'welcome tabs')
old = '''              <div className="oj-public-contest-actions">{status === 'ended' ? <><button onClick={() => onReviewQuestions(exam)}>صورت سؤال</button><button onClick={() => onLeaderboard(exam)}>رتبه‌بندی</button></> : <button className="primary" onClick={status === 'upcoming' ? onRegister : onLogin}>{status === 'upcoming' ? 'ثبت‌نام' : 'ورود به مسابقه'} <ArrowLeft size={14} /></button>}</div>'''
new = '''              <div className="oj-public-contest-actions">
                <div className="oj-contest-utility-actions">
                  <button type="button" className={savedSet.has(exam.id) ? 'oj-save-action is-saved' : 'oj-save-action'} aria-pressed={savedSet.has(exam.id)} onClick={() => onToggleSaved(exam.id)} title={savedSet.has(exam.id) ? 'حذف از ذخیره‌شده‌ها' : 'ذخیره در فهرست شخصی'}>{savedSet.has(exam.id) ? <BookmarkCheck size={14} /> : <Bookmark size={14} />}{savedSet.has(exam.id) ? 'ذخیره‌شده' : 'ذخیره'}</button>
                  {status === 'upcoming' && <button type="button" className="oj-calendar-action" onClick={() => onAddToCalendar(exam)} title="افزودن به تقویم با یادآور ۱۵ دقیقه قبل"><CalendarPlus size={14} />تقویم</button>}
                </div>
                {status === 'ended' ? <><button onClick={() => onReviewQuestions(exam)}>صورت سؤال</button><button onClick={() => onLeaderboard(exam)}>رتبه‌بندی</button></> : <button className="primary" onClick={status === 'upcoming' ? onRegister : onLogin}>{status === 'upcoming' ? 'ثبت‌نام' : 'ورود به مسابقه'} <ArrowLeft size={14} /></button>}
              </div>'''
app = rep(app, old, new, 'public row actions')

# Logged-in dashboard uses the exact same watchlist and calendar functions.
app = rep(app, 'function Dashboard({ exams, profile, now, onOpen, onAdmin, isAdmin, isDemo, myRegistrations, myTeamRegistrations, team, onRegister, onReviewQuestions, onLeaderboard }: {',
          'function Dashboard({ exams, profile, now, onOpen, onAdmin, isAdmin, isDemo, myRegistrations, myTeamRegistrations, team, onRegister, onReviewQuestions, onLeaderboard, savedContestIds, onToggleSaved, onAddToCalendar }: {', 'dashboard props')
app = rep(app, '  onReviewQuestions: (exam: Exam) => void; onLeaderboard: (exam: Exam) => void\n}) {\n  const [filter, setFilter] = useState<\'all\' | \'active\' | \'upcoming\' | \'ended\'>(\'all\')',
          '  onReviewQuestions: (exam: Exam) => void; onLeaderboard: (exam: Exam) => void\n  savedContestIds: string[]; onToggleSaved: (id: string) => void; onAddToCalendar: (exam: Exam) => void\n}) {\n  const [filter, setFilter] = useState<\'all\' | \'active\' | \'upcoming\' | \'ended\' | \'saved\'>(\'all\')', 'dashboard prop types')
app = rep(app, '  const registered = new Set([...myRegistrations, ...myTeamRegistrations])\n  const next = upcoming[0]\n  const list = (filter === \'active\' ? active : filter === \'upcoming\' ? upcoming : filter === \'ended\' ? ended : exams)\n',
          '  const registered = new Set([...myRegistrations, ...myTeamRegistrations])\n  const saved = new Set(savedContestIds)\n  const savedExams = exams.filter((exam) => saved.has(exam.id))\n  const next = upcoming[0]\n  const list = (filter === \'saved\' ? savedExams : filter === \'active\' ? active : filter === \'upcoming\' ? upcoming : filter === \'ended\' ? ended : exams)\n', 'dashboard saved list')
app = rep(app, '      <div className="oj-stat-card oj-stat-card-static"><span className="oj-stat-icon amber"><CheckCircle2 size={18} /></span><span><small>ثبت‌نام‌های من</small><strong>{fa(registered.size)}</strong></span></div>\n',
          '      <div className="oj-stat-card oj-stat-card-static"><span className="oj-stat-icon amber"><CheckCircle2 size={18} /></span><span><small>ثبت‌نام‌های من</small><strong>{fa(registered.size)}</strong></span></div>\n      <button className={filter === \'saved\' ? \'oj-stat-card is-selected\' : \'oj-stat-card\'} onClick={() => setFilter(\'saved\')}><span className="oj-stat-icon violet"><BookmarkCheck size={18} /></span><span><small>ذخیره‌شده‌ها</small><strong>{fa(savedExams.length)}</strong></span></button>\n', 'dashboard saved card')
app = rep(app, "{([['all','همه'],['active','فعال'],['upcoming','آینده'],['ended','پایان‌یافته']] as const).map(([value,label]) => <button key={value} className={filter === value ? 'active' : ''} onClick={() => setFilter(value)}>{label}<span>{value === 'all' ? exams.length : value === 'active' ? active.length : value === 'upcoming' ? upcoming.length : ended.length}</span></button>)}",
          "{([['all','همه'],['active','فعال'],['upcoming','آینده'],['ended','پایان‌یافته'],['saved','ذخیره‌شده‌ها']] as const).map(([value,label]) => <button key={value} className={filter === value ? 'active' : ''} onClick={() => setFilter(value)}>{label}<span>{value === 'all' ? exams.length : value === 'active' ? active.length : value === 'upcoming' ? upcoming.length : value === 'ended' ? ended.length : savedExams.length}</span></button>)}", 'dashboard tabs')
old = '''            <div className="oj-contest-row-actions">
              {status === 'upcoming' && !isRegistered && <button className="button soft small" onClick={() => onRegister(exam)}><UserPlus size={14} /> ثبت‌نام</button>}'''
new = '''            <div className="oj-contest-row-actions">
              <div className="oj-contest-utility-actions">
                <button type="button" className={saved.has(exam.id) ? 'oj-save-action is-saved' : 'oj-save-action'} aria-pressed={saved.has(exam.id)} onClick={() => onToggleSaved(exam.id)} title={saved.has(exam.id) ? 'حذف از ذخیره‌شده‌ها' : 'ذخیره در فهرست شخصی'}>{saved.has(exam.id) ? <BookmarkCheck size={14} /> : <Bookmark size={14} />}{saved.has(exam.id) ? 'ذخیره‌شده' : 'ذخیره'}</button>
                {status === 'upcoming' && <button type="button" className="oj-calendar-action" onClick={() => onAddToCalendar(exam)} title="افزودن به تقویم با یادآور ۱۵ دقیقه قبل"><CalendarPlus size={14} />تقویم</button>}
              </div>
              {status === 'upcoming' && !isRegistered && <button className="button soft small" onClick={() => onRegister(exam)}><UserPlus size={14} /> ثبت‌نام</button>}'''
app = rep(app, old, new, 'dashboard row actions')
app = rep(app, '<ShieldCheck size={15} />پاسخ‌های مسابقه‌های فعال به‌صورت خودکار ذخیره می‌شوند.</div>',
          '<ShieldCheck size={15} />پاسخ‌های مسابقه‌های فعال به‌صورت خودکار ذخیره می‌شوند؛ فهرست ذخیره‌ها فقط روی همین مرورگر نگهداری می‌شود.</div>', 'watchlist scope note')

app = rep(app, "      onLeaderboard={(exam) => { setSelectedPublicExam(exam); setPage('leaderboard') }}\n    />",
          "      onLeaderboard={(exam) => { setSelectedPublicExam(exam); setPage('leaderboard') }}\n      savedContestIds={savedContestIds}\n      onToggleSaved={toggleSavedContest}\n      onAddToCalendar={addContestToCalendar}\n    />", 'welcome props wire')
app = rep(app, "          onLeaderboard={(exam) => { setSelectedPublicExam(exam); setPage('leaderboard') }}\n        />}",
          "          onLeaderboard={(exam) => { setSelectedPublicExam(exam); setPage('leaderboard') }}\n          savedContestIds={savedContestIds}\n          onToggleSaved={toggleSavedContest}\n          onAddToCalendar={addContestToCalendar}\n        />}", 'dashboard props wire')

css += r'''

/* FJ PERSONAL CONTEST TOOLS v1 — watchlist and calendar actions */
.oj-contest-utility-actions { display:flex; align-items:center; flex-wrap:wrap; gap:6px; }
.oj-save-action,.oj-calendar-action { min-height:34px; padding:0 10px; display:inline-flex; align-items:center; justify-content:center; gap:6px; border:1px solid var(--line); border-radius:9px; background:var(--panel-2); color:var(--muted); font:inherit; font-size:9px; font-weight:800; white-space:nowrap; transition:transform .16s,border-color .16s,background .16s,color .16s; }
.oj-save-action:hover,.oj-calendar-action:hover { transform:translateY(-1px); border-color:rgba(139,115,246,.4); color:var(--text); }
.oj-save-action.is-saved { border-color:rgba(139,115,246,.36); background:rgba(139,115,246,.12); color:#a995ff; }
.oj-save-action.is-saved svg { fill:rgba(139,115,246,.18); }
.oj-calendar-action { color:var(--green); }
.oj-calendar-action:hover { border-color:rgba(56,201,154,.4); }
.oj-stat-grid { grid-template-columns:repeat(5,minmax(0,1fr)); }
.oj-filter-tabs button:focus-visible,.oj-save-action:focus-visible,.oj-calendar-action:focus-visible { outline:2px solid var(--oj-accent,var(--purple)); outline-offset:2px; }
@media (min-width:701px) and (max-width:1100px) { .oj-stat-grid { grid-template-columns:repeat(3,minmax(0,1fr)); } }
@media (max-width:700px) { .oj-stat-grid { grid-template-columns:repeat(2,minmax(0,1fr)) !important; } .oj-contest-utility-actions { width:100%; } .oj-save-action,.oj-calendar-action { min-height:40px; padding-inline:11px; } }
@media (prefers-reduced-motion:reduce) { .oj-save-action,.oj-calendar-action { transition:none; } }
'''

app_path.write_text(app, encoding='utf-8')
css_path.write_text(css, encoding='utf-8')
print('Added the persistent contest watchlist and calendar export with a 15-minute reminder.')
