# آزمون‌یار | FarsiJudge

A Persian (RTL) numeric-answer online judge starter. The frontend is a static React/Vite application for GitHub Pages; authentication, database storage, authorization and grading are handled by Supabase.

## Implemented in this starter

- Persian interface with responsive layout and light/dark themes.
- Email/password registration and login through Supabase Auth.
- Participant dashboard and profile page.
- Admin-only exam creation: title, description, scheduled start, duration, question count, answer key and points.
- Question statements are intentionally **not stored or displayed**. Participants see only question numbers and answer fields.
- Server-clock-based countdown display; database policies are authoritative for start/end times.
- Automatic answer saving while an exam is active.
- One attempt per participant and exam; a participant who opens an exam but submits no answers is still graded with zero.
- Exact numeric comparison in PostgreSQL `NUMERIC` (for example, `2` and `2.0` compare equal as numbers).
- Results are available to participants only after the scheduled end.
- Optional Supabase Cron job for grading expired attempts even when nobody is online.

## Requirements

- Node.js 22 or newer
- A GitHub account
- A Supabase project

## 1. Create the Supabase database

1. Create a project at [supabase.com](https://supabase.com/).
2. Open **SQL Editor** in the Supabase dashboard.
3. Run the complete file `supabase/migrations/001_initial_schema.sql`.
4. Open **Project Settings → API** and copy the Project URL and the publishable key. The legacy `anon` key is also supported. Never use a `service_role` or secret key in this frontend.
5. In **Authentication → URL Configuration**, add your local URL and the exact GitHub Pages URL to the allowed redirect URLs. Example:
   - `http://localhost:5173/`
   - `https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPOSITORY/`
6. Email confirmation is recommended for a public registration flow. Configure the email provider/templates in Supabase Auth. For a private test environment, you may temporarily disable confirmation in Auth settings, but turn it back on before using real participant accounts.

## 2. Create the first admin account

1. Register from the website with the email address that should own the admin account.
2. Confirm the email if confirmation is enabled, then sign in once so the profile row is created.
3. In Supabase **SQL Editor**, run the following after replacing the email:

```sql
update public.profiles
set role = 'admin'
where id = (
  select id from auth.users
  where email = lower('admin@example.com')
);
```

4. Sign out and sign in again. The navigation should now show **مدیریت آزمون‌ها**.

Roles are stored in `public.profiles`; users cannot change their own role through the app. Only an admin can create and publish exams.

## 3. Run locally

```bash
cp .env.example .env
```

Edit `.env` and set your Supabase values:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Then install and run:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (normally `http://localhost:5173`). Without Supabase settings, the app provides a non-persistent demo preview; registration and real exam submission are disabled until Supabase is configured.

## 4. Deploy to GitHub Pages

1. Create a GitHub repository (for example `farsijudge`) and push the **contents** of this folder to its `main` branch.
2. Open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
3. Open **Settings → Secrets and variables → Actions → Variables** and add:
   - `VITE_SUPABASE_URL` = your Supabase Project URL
   - `VITE_SUPABASE_PUBLISHABLE_KEY` = your Supabase publishable key

   If your project only has the legacy anon key, add `VITE_SUPABASE_ANON_KEY` instead.
4. Push to `main` (or run the workflow manually from **Actions**). The included `.github/workflows/deploy.yml` builds the app and publishes `dist/` to GitHub Pages.
5. Your site will be available at `https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPOSITORY/`.
6. Add that exact URL to Supabase Auth's allowed redirect URLs as described above.

Vite needs the repository sub-path for GitHub Pages. The workflow sets `VITE_BASE_PATH` automatically from the repository name.

## 5. Automatic grading when nobody is online (optional but recommended)

The app can trigger grading when a signed-in user opens the dashboard or an ended exam. To grade even when nobody visits the site, enable **Supabase Cron (pg_cron)** in the Supabase dashboard under **Integrations → Cron**, then run `supabase/cron.sql` once in the SQL Editor.

The job runs every minute and processes ended exams with attempts that do not yet have a result. You can inspect it with the query included at the bottom of `supabase/cron.sql`.

## Important security notes

- GitHub Pages hosts only the frontend. It does not host the database or server logic.
- Supabase Row Level Security is enabled on all exposed tables.
- The answer key is in a separate table and is readable only by admins. Never add the key or a Supabase secret/service-role key to frontend code or GitHub Actions variables used by the browser build.
- The database validates exam start/end times. Changing the browser clock does not extend the submission window.
- Autosave needs an active internet connection. If a participant loses connection, changes that have not reached Supabase may not be saved.
- This is a functional starter, not a complete high-stakes examination platform. Before a large or high-stakes exam, test with multiple accounts and devices, verify email delivery, test database policies, and consider adding CAPTCHA/rate limiting, audit logs, backups, and explicit participant enrollment.

## Project structure

```text
src/
  App.tsx                 Main UI and exam workflow
  style.css               Responsive Persian light/dark design
  lib/supabase.ts         Supabase client
supabase/
  migrations/             Database schema, RLS and grading functions
  cron.sql                Optional scheduled grading
.github/workflows/
  deploy.yml              GitHub Pages deployment
.env.example              Frontend environment variables
```
