import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  // GitHub Actions sets VITE_BASE_PATH to /<repository-name>/.
  // Locally and on a custom root domain, the default is '/'.
  base: process.env.VITE_BASE_PATH || '/',
})
