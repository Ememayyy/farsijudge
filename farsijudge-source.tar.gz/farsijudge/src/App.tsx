import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { FormEvent, ReactNode } from 'react'
import type { Session } from '@supabase/supabase-js'
import {
  ArrowLeft, Award, BookOpen, CheckCircle2, ChevronLeft, Clock3,
  GraduationCap, LayoutDashboard, LogOut, Moon, Plus, RefreshCw, ShieldCheck,
  Sun, UserRound, Users, XCircle,
} from 'lucide-react'
import { isSupabaseConfigured, supabase } from './lib/supabase'

type Profile = { id: string; full_name: string; role: 'participant' | 'admin' }
type Exam = {
  id: string
  title: string
  description: string | null
  starts_at: string
  duration_minutes: number
  is_published: boolean
  created_at?: string
}
type Question = { id: string; exam_id: string; question_number: number; points: number }
type ExamResult = {
  id: string
  exam_id: string
  user_id: string
  score: number
  max_score: number
  correct_count: number
  question_count: number
  graded_at: string
}
type Page = 'dashboard' | 'exam' | 'admin' | 'profile'

type AdminQuestion = { answer: string; points: string }

const demoExams: Exam[] = [
  {
    id: 'demo-exam-1', title: 'آزمون آزمایشی ریاضی',
    description: 'یک آزمون نمونه برای آشنایی با محیط سامانه.',
    starts_at: new Date(Date.now() - 35 * 60_000).toISOString(),
    duration_minutes: 120, is_published: true,
  },
  {
    id: 'demo-exam-2', title: 'آزمون مرحله دوم',
    description: 'این آزمون هنوز شروع نشده است.',
    starts_at: new Date(Date.now() + 2 * 24 * 60 * 60_000).toISOString(),
    duration_minutes: 120, is_published: true,
  },
  {
    id: 'demo-exam-3', title: 'آزمون مبانی ترکیبیات',
    description: 'نمونه‌ای از آزمون پایان‌یافته.',
    starts_at: new Date(Date.now() - 5 * 24 * 60 * 60_000).toISOString(),
    duration_minutes: 120, is_published: true,
  },
]
const demoQuestions: Question[] = Array.from({ length: 8 }, (_, i) => ({
  id: `q-${i + 1}`, exam_id: 'demo-exam-1', question_number: i + 1, points: i < 4 ? 2 : 3,
}))
const demoUser = { id: 'demo-user', email: 'demo@example.com' }
const numberFormat = new Intl.NumberFormat('fa-IR')
const fa = (value: number | string) => {
  const numeric = Number(value)
  return Number.isFinite(numeric) ? numberFormat.format(numeric) : String(value)
}
const normalizeNumber = (value: string) => value.trim()
  .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
  .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
  .replace(/٫/g, '.')
  .replace(/−/g, '-')
const validNumber = (value: string) => /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(normalizeNumber(value))
const examEnd = (exam: Exam) => new Date(new Date(exam.starts_at).getTime() + exam.duration_minutes * 60_000)
const getStatus = (exam: Exam, now = Date.now()) => {
  const start = new Date(exam.starts_at).getTime()
  const end = examEnd(exam).getTime()
  if (now < start) return 'upcoming' as const
  if (now < end) return 'active' as const
  return 'ended' as const
}
const dateText = (iso: string) => new Date(iso).toLocaleString('fa-IR', {
  year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit',
})
const durationText = (seconds: number) => {
  const safe = Math.max(0, seconds)
  const h = Math.floor(safe / 3600)
  const m = Math.floor((safe % 3600) / 60)
  const s = safe % 60
  return h > 0 ? `${fa(h)}:${fa(m).padStart(2, '۰')}:${fa(s).padStart(2, '۰')}` : `${fa(m)}:${fa(s).padStart(2, '۰')}`
}

export default function App() {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [demoMode, setDemoMode] = useState(false)
  const [page, setPage] = useState<Page>('dashboard')
  const [exams, setExams] = useState<Exam[]>([])
  const [selectedExam, setSelectedExam] = useState<Exam | null>(null)
  const [questions, setQuestions] = useState<Question[]>([])
  const [answerValues, setAnswerValues] = useState<Record<number, string>>({})
  const [examResult, setExamResult] = useState<ExamResult | null>(null)
  const [now, setNow] = useState(Date.now())
  const [clockOffset, setClockOffset] = useState(0)
  const [loading, setLoading] = useState(true)
  const [notice, setNotice] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null)
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('farsijudge-theme')
    return saved === 'light' ? 'light' : 'dark'
  })
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login')
  const [authEmail, setAuthEmail] = useState('')
  const [authPassword, setAuthPassword] = useState('')
  const [authName, setAuthName] = useState('')
  const [authBusy, setAuthBusy] = useState(false)
  const [saving, setSaving] = useState(false)
  const [answerDirty, setAnswerDirty] = useState(false)
  const [adminTitle, setAdminTitle] = useState('')
  const [adminDescription, setAdminDescription] = useState('')
  const [adminStart, setAdminStart] = useState(() => {
    const d = new Date(Date.now() + 60 * 60_000)
    d.setMinutes(Math.ceil(d.getMinutes() / 5) * 5, 0, 0)
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60_000)
    return local.toISOString().slice(0, 16)
  })
  const [adminDuration, setAdminDuration] = useState('120')
  const [adminQuestions, setAdminQuestions] = useState<AdminQuestion[]>([
    { answer: '', points: '1' }, { answer: '', points: '1' }, { answer: '', points: '1' },
  ])
  const [adminBusy, setAdminBusy] = useState(false)
  const [adminResults, setAdminResults] = useState<ExamResult[]>([])
  const [profiles, setProfiles] = useState<Profile[]>([])
  const finalizedRef = useRef<Set<string>>(new Set())

  const userId = session?.user.id ?? (demoMode ? demoUser.id : null)
  const isAdmin = profile?.role === 'admin'
  const isDemo = demoMode && !session
  const isLoggedIn = Boolean(userId)
  const selectedStatus = selectedExam ? getStatus(selectedExam, now) : null

  useEffect(() => {
    document.documentElement.dataset.theme = theme
    localStorage.setItem('farsijudge-theme', theme)
  }, [theme])

  useEffect(() => {
    if (!supabase) {
      setLoading(false)
      setExams(demoExams)
      return
    }
    let alive = true
    supabase.auth.getSession().then(({ data }) => {
      if (alive) {
        setSession(data.session)
        setLoading(false)
      }
    })
    const { data: authListener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession)
      if (!nextSession) {
        setProfile(null)
        setExams([])
        setPage('dashboard')
      }
    })
    return () => {
      alive = false
      authListener.subscription.unsubscribe()
    }
  }, [])

  const loadMainData = useCallback(async () => {
    if (!supabase || !session?.user.id) return
    const { data: serverTime } = await supabase.rpc('server_time')
    if (serverTime) {
      const nextOffset = Date.parse(serverTime) - Date.now()
      if (Math.abs(nextOffset - clockOffset) > 1000) setClockOffset(nextOffset)
    }
    const [profileResponse, examResponse] = await Promise.all([
      supabase.from('profiles').select('id,full_name,role').eq('id', session.user.id).single(),
      supabase.from('exams').select('id,title,description,starts_at,duration_minutes,is_published,created_at').order('starts_at', { ascending: false }),
    ])
    if (profileResponse.data) setProfile(profileResponse.data as Profile)
    if (examResponse.error) setNotice({ type: 'error', text: `دریافت آزمون‌ها ناموفق بود: ${examResponse.error.message}` })
    if (examResponse.data) {
      const rows = examResponse.data as Exam[]
      setExams(rows)
      // A browser that is online at or after the deadline can trigger finalization.
      // Supabase Cron (optional SQL file) covers the case where nobody is online.
      for (const exam of rows) {
        if (getStatus(exam, Date.now() + clockOffset) === 'ended' && !finalizedRef.current.has(exam.id)) {
          finalizedRef.current.add(exam.id)
          void supabase.rpc('finalize_exam', { p_exam_id: exam.id })
        }
      }
    }
  }, [session?.user.id, clockOffset])

  useEffect(() => {
    if (session?.user.id) void loadMainData()
    else if (!session && !demoMode) setLoading(false)
  }, [session?.user.id, demoMode, loadMainData])

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now() + clockOffset), 1000)
    setNow(Date.now() + clockOffset)
    return () => window.clearInterval(timer)
  }, [clockOffset])

  useEffect(() => {
    if (!selectedExam || page !== 'exam') return
    if (isDemo) {
      setQuestions(selectedExam.id === 'demo-exam-1' ? demoQuestions : [])
      setAnswerValues({})
      setExamResult(selectedExam.id === 'demo-exam-3' ? {
        id: 'demo-result', exam_id: selectedExam.id, user_id: demoUser.id,
        score: 13, max_score: 20, correct_count: 5, question_count: 8, graded_at: new Date().toISOString(),
      } : null)
      return
    }
    if (!supabase || !session?.user.id) return
    let alive = true
    const load = async () => {
      if (selectedStatus === 'active') {
        const { error: startError } = await supabase.rpc('start_exam', { p_exam_id: selectedExam.id })
        if (startError) {
          if (alive) setNotice({ type: 'error', text: `شروع آزمون انجام نشد: ${startError.message}` })
          return
        }
      }
      const [qRes, aRes] = await Promise.all([
        supabase.from('exam_questions').select('id,exam_id,question_number,points').eq('exam_id', selectedExam.id).order('question_number'),
        supabase.from('exam_answers').select('question_number,answer').eq('exam_id', selectedExam.id).eq('user_id', session.user.id),
      ])
      if (!alive) return
      if (qRes.error) setNotice({ type: 'error', text: qRes.error.message })
      if (qRes.data) setQuestions(qRes.data as Question[])
      if (aRes.data) {
        const answers: Record<number, string> = {}
        for (const row of aRes.data as { question_number: number; answer: number | string }[]) answers[row.question_number] = String(row.answer)
        setAnswerValues(answers)
      }
      if (getStatus(selectedExam) === 'ended') {
        await supabase.rpc('finalize_exam', { p_exam_id: selectedExam.id })
        const resultRes = await supabase.from('exam_results').select('*').eq('exam_id', selectedExam.id).eq('user_id', session.user.id).maybeSingle()
        if (alive && resultRes.data) setExamResult(resultRes.data as ExamResult)
      }
    }
    void load()
    return () => { alive = false }
  }, [selectedExam?.id, selectedStatus, page, session?.user.id, isDemo])

  useEffect(() => {
    if (!selectedExam || page !== 'exam' || getStatus(selectedExam, now) !== 'ended' || isDemo || !supabase || !session?.user.id) return
    if (finalizedRef.current.has(selectedExam.id)) return
    finalizedRef.current.add(selectedExam.id)
    void (async () => {
      const { error } = await supabase.rpc('finalize_exam', { p_exam_id: selectedExam.id })
      if (error) setNotice({ type: 'error', text: error.message })
      const { data } = await supabase.from('exam_results').select('*').eq('exam_id', selectedExam.id).eq('user_id', session.user.id).maybeSingle()
      if (data) setExamResult(data as ExamResult)
    })()
  }, [selectedExam, page, now, isDemo, session?.user.id])

  useEffect(() => {
    if (!answerDirty || !selectedExam || page !== 'exam' || selectedStatus !== 'active') return
    setSaving(true)
    const timeout = window.setTimeout(async () => {
      if (isDemo) {
        setSaving(false)
        setAnswerDirty(false)
        return
      }
      if (!supabase || !session?.user.id) return
      const operations = (Object.entries(answerValues) as [string, string][]).map(async ([question, raw]) => {
        const questionNumber = Number(question)
        if (!raw.trim()) {
          return supabase.from('exam_answers').delete()
            .eq('exam_id', selectedExam.id).eq('user_id', session.user.id).eq('question_number', questionNumber)
        }
        if (!validNumber(raw)) return null
        return supabase.from('exam_answers').upsert({
          exam_id: selectedExam.id,
          user_id: session.user.id,
          question_number: questionNumber,
          answer: normalizeNumber(raw),
        }, { onConflict: 'exam_id,user_id,question_number' })
      })
      const responses = await Promise.all(operations)
      const error = responses.find((item) => item && item.error)?.error
      if (error) setNotice({ type: 'error', text: `ذخیره پاسخ انجام نشد: ${error.message}` })
      else setNotice({ type: 'success', text: 'پاسخ‌ها ذخیره شدند.' })
      setSaving(false)
      setAnswerDirty(false)
    }, 650)
    return () => window.clearTimeout(timeout)
  }, [answerValues, answerDirty, selectedExam?.id, page, isDemo, session?.user.id])

  useEffect(() => {
    if (!isAdmin || !supabase || !session?.user.id || page !== 'admin') return
    let alive = true
    const loadAdmin = async () => {
      const [r, p] = await Promise.all([
        supabase.from('exam_results').select('*').order('graded_at', { ascending: false }).limit(100),
        supabase.from('profiles').select('id,full_name,role'),
      ])
      if (!alive) return
      if (r.data) setAdminResults(r.data as ExamResult[])
      if (p.data) setProfiles(p.data as Profile[])
    }
    void loadAdmin()
    return () => { alive = false }
  }, [isAdmin, page, session?.user.id])

  const notify = (text: string, type: 'success' | 'error' | 'info' = 'info') => {
    setNotice({ text, type })
    window.setTimeout(() => setNotice((current) => current?.text === text ? null : current), 4500)
  }

  const handleAuth = async (event: FormEvent) => {
    event.preventDefault()
    if (!supabase) return
    if (!authEmail.trim() || !authPassword) return notify('ایمیل و رمز عبور را وارد کنید.', 'error')
    if (authPassword.length < 8) return notify('رمز عبور باید حداقل ۸ کاراکتر باشد.', 'error')
    setAuthBusy(true)
    if (authMode === 'register') {
      if (!authName.trim()) {
        setAuthBusy(false)
        return notify('نام و نام خانوادگی را وارد کنید.', 'error')
      }
      const { data, error } = await supabase.auth.signUp({
        email: authEmail.trim(),
        password: authPassword,
        options: { data: { full_name: authName.trim() }, emailRedirectTo: window.location.origin + window.location.pathname },
      })
      if (error) notify(error.message, 'error')
      else if (data.session) notify('حساب شما ساخته شد. خوش آمدید!', 'success')
      else notify('ثبت‌نام انجام شد. برای فعال‌سازی، ایمیل تأیید را بررسی کنید.', 'success')
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email: authEmail.trim(), password: authPassword })
      if (error) notify('ورود انجام نشد؛ ایمیل و رمز عبور را بررسی کنید.', 'error')
      else notify('با موفقیت وارد شدید.', 'success')
    }
    setAuthBusy(false)
  }

  const enterDemo = () => {
    setDemoMode(true)
    setProfile({ id: demoUser.id, full_name: 'کاربر آزمایشی', role: 'participant' })
    setExams(demoExams)
    setPage('dashboard')
  }

  const signOut = async () => {
    if (isDemo) {
      setDemoMode(false)
      setProfile(null)
      setExams([])
    } else if (supabase) {
      await supabase.auth.signOut()
    }
    setSelectedExam(null)
    setPage('dashboard')
  }

  const openExam = (exam: Exam) => {
    setSelectedExam(exam)
    setQuestions([])
    setAnswerValues({})
    setExamResult(null)
    setAnswerDirty(false)
    setPage('exam')
  }

  const saveAnswer = (questionNumber: number, value: string) => {
    setAnswerValues((current) => ({ ...current, [questionNumber]: value }))
    setAnswerDirty(true)
  }

  const createExam = async (event: FormEvent) => {
    event.preventDefault()
    if (!supabase || !session?.user.id) return
    if (!adminTitle.trim()) return notify('عنوان آزمون را وارد کنید.', 'error')
    if (!adminStart || !Number.isFinite(new Date(adminStart).getTime()) || new Date(adminStart).getTime() <= Date.now()) return notify('زمان شروع آزمون باید در آینده باشد.', 'error')
    if (!Number.isInteger(Number(adminDuration)) || Number(adminDuration) < 1 || Number(adminDuration) > 600) return notify('مدت آزمون باید بین ۱ تا ۶۰۰ دقیقه باشد.', 'error')
    if (adminQuestions.length < 1 || adminQuestions.some((q) => !q.answer.trim() || !validNumber(q.answer) || !q.points.trim() || Number(q.points) <= 0)) {
      return notify('برای همه سؤال‌ها پاسخ عددی معتبر و نمره مثبت تعیین کنید.', 'error')
    }
    setAdminBusy(true)
    const { error } = await supabase.rpc('create_exam_with_answer_key', {
      p_title: adminTitle.trim(),
      p_description: adminDescription.trim(),
      p_starts_at: new Date(adminStart).toISOString(),
      p_duration_minutes: Number(adminDuration),
      p_questions: adminQuestions.map((q, i) => ({ question_number: i + 1, points: q.points, correct_answer: normalizeNumber(q.answer) })),
    })
    if (error) notify(`ساخت آزمون ناموفق بود: ${error.message}`, 'error')
    else {
      notify('آزمون با موفقیت ساخته و منتشر شد.', 'success')
      setAdminTitle('')
      setAdminDescription('')
      setAdminQuestions([{ answer: '', points: '1' }, { answer: '', points: '1' }, { answer: '', points: '1' }])
      await loadMainData()
    }
    setAdminBusy(false)
  }

  const changeQuestionCount = (count: number) => {
    const safe = Math.max(1, Math.min(100, count))
    setAdminQuestions((current) => Array.from({ length: safe }, (_, i) => current[i] ?? { answer: '', points: '1' }))
  }

  const activeExamStatus = selectedStatus
  const remainingSeconds = selectedExam && activeExamStatus === 'active'
    ? Math.max(0, Math.ceil((examEnd(selectedExam).getTime() - now) / 1000)) : 0
  const questionScore = useMemo(() => questions.reduce((sum, q) => sum + Number(q.points), 0), [questions])

  if (loading) return <div className="loading-screen"><div className="brand-mark"><GraduationCap size={26} /></div><span>در حال آماده‌سازی سامانه...</span></div>

  if (!isLoggedIn) {
    return <div className="auth-shell">
      <div className="auth-visual">
        <div className="auth-glow glow-one" /><div className="auth-glow glow-two" />
        <div className="auth-visual-content">
          <div className="brand brand-light"><span className="brand-mark"><GraduationCap size={27} /></span><span>آزمون‌یار</span></div>
          <div className="auth-kicker">سامانه برگزاری آزمون آنلاین</div>
          <h1>تمرکز روی حل مسئله،<br /><span>نه حاشیه‌ها.</span></h1>
          <p>محیطی ساده و امن برای آزمون‌های عددی، با ثبت خودکار پاسخ‌ها و تصحیح دقیق.</p>
          <div className="auth-feature-list">
            <div><CheckCircle2 size={18} /><span>زمان‌بندی دقیق آزمون‌ها</span></div>
            <div><CheckCircle2 size={18} /><span>ذخیره خودکار پاسخ‌ها</span></div>
            <div><CheckCircle2 size={18} /><span>تصحیح عددی دقیق و خودکار</span></div>
          </div>
        </div>
        <div className="auth-visual-footer">آزمون‌یار · نسخهٔ نخست</div>
      </div>
      <div className="auth-panel">
        <div className="auth-panel-top">
          <button className="icon-button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="تغییر تم">
            {theme === 'dark' ? <Sun size={19} /> : <Moon size={19} />}
          </button>
          <span className="muted small">{authMode === 'login' ? 'حساب کاربری دارید؟' : 'قبلاً ثبت‌نام کرده‌اید؟'}</span>
        </div>
        <div className="auth-form-wrap">
          <div className="mobile-brand"><span className="brand-mark"><GraduationCap size={25} /></span><b>آزمون‌یار</b></div>
          <div className="eyebrow">خوش آمدید</div>
          <h2>{authMode === 'login' ? 'ورود به حساب' : 'ساخت حساب کاربری'}</h2>
          <p className="muted auth-subtitle">{authMode === 'login' ? 'برای ادامه، اطلاعات حساب خود را وارد کنید.' : 'برای شرکت در آزمون‌ها، حساب خود را بسازید.'}</p>
          <form className="form-stack" onSubmit={handleAuth}>
            {authMode === 'register' && <label className="field-label">نام و نام خانوادگی<input value={authName} onChange={(e) => setAuthName(e.target.value)} placeholder="مثلاً محمدمهدی افشار" autoComplete="name" /></label>}
            <label className="field-label">ایمیل (نام کاربری)<input type="email" value={authEmail} onChange={(e) => setAuthEmail(e.target.value)} placeholder="name@example.com" autoComplete="email" dir="ltr" /></label>
            <label className="field-label">رمز عبور<input type="password" value={authPassword} onChange={(e) => setAuthPassword(e.target.value)} placeholder="حداقل ۸ کاراکتر" autoComplete={authMode === 'login' ? 'current-password' : 'new-password'} dir="ltr" /></label>
            <button className="button primary full" disabled={authBusy} type="submit">{authBusy ? 'در حال بررسی...' : authMode === 'login' ? 'ورود به سامانه' : 'ایجاد حساب'}<ArrowLeft size={17} /></button>
          </form>
          <div className="auth-switch">
            {authMode === 'login' ? 'حساب ندارید؟' : 'حساب دارید؟'}
            <button onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}>{authMode === 'login' ? 'ثبت‌نام کنید' : 'وارد شوید'}</button>
          </div>
          {!isSupabaseConfigured && <div className="demo-box"><div><strong>پیش‌نمایش رابط کاربری</strong><span>اتصال دیتابیس هنوز تنظیم نشده است؛ با ورود نمایشی می‌توانید ظاهر سامانه را ببینید.</span></div><button className="button secondary" onClick={enterDemo}>ورود نمایشی</button></div>}
          {notice && <Notice notice={notice} onClose={() => setNotice(null)} />}
          <div className="security-note"><ShieldCheck size={16} /> اطلاعات حساب شما به‌صورت امن مدیریت می‌شود.</div>
        </div>
      </div>
    </div>
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark"><GraduationCap size={25} /></span><span>آزمون‌یار</span></div>
      <div className="workspace-label">فضای کاربری</div>
      <nav className="side-nav">
        <button className={page === 'dashboard' ? 'nav-item selected' : 'nav-item'} onClick={() => setPage('dashboard')}><LayoutDashboard size={19} />داشبورد</button>
        {isAdmin && <button className={page === 'admin' ? 'nav-item selected' : 'nav-item'} onClick={() => setPage('admin')}><ShieldCheck size={19} />مدیریت آزمون‌ها</button>}
        <button className={page === 'profile' ? 'nav-item selected' : 'nav-item'} onClick={() => setPage('profile')}><UserRound size={19} />پروفایل من</button>
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-help"><div className="help-icon"><BookOpen size={18} /></div><strong>راهنمای آزمون</strong><p>پاسخ‌ها را در زمان آزمون وارد کنید؛ ذخیره به‌صورت خودکار انجام می‌شود.</p></div>
        <div className="user-mini"><div className="avatar">{(profile?.full_name || 'ک').slice(0, 1)}</div><div className="user-mini-info"><b>{profile?.full_name || 'کاربر'}</b><span>{isAdmin ? 'مدیر سامانه' : 'شرکت‌کننده'}</span></div><button className="icon-button subtle" onClick={signOut} aria-label="خروج"><LogOut size={17} /></button></div>
      </div>
    </aside>

    <main className="main-area">
      <header className="topbar">
        <div className="breadcrumb"><span>آزمون‌یار</span><ChevronLeft size={15} /><b>{page === 'dashboard' ? 'داشبورد' : page === 'exam' ? 'صفحه آزمون' : page === 'admin' ? 'مدیریت آزمون‌ها' : 'پروفایل من'}</b></div>
        <div className="top-actions">
          {isDemo && <span className="demo-pill">حالت نمایشی</span>}
          <button className="icon-button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="تغییر تم">
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <div className="top-avatar">{(profile?.full_name || 'ک').slice(0, 1)}</div>
        </div>
      </header>

      <div className="page-content">
        {page === 'dashboard' && <Dashboard
          exams={exams} profile={profile} now={now} onOpen={openExam} onAdmin={() => setPage('admin')}
          isAdmin={isAdmin} isDemo={isDemo} onRefresh={loadMainData}
        />}
        {page === 'exam' && selectedExam && <ExamPage
          exam={selectedExam} questions={questions} answers={answerValues}
          remainingSeconds={remainingSeconds} status={activeExamStatus!} result={examResult}
          saving={saving} demo={isDemo} onAnswer={saveAnswer} onBack={() => setPage('dashboard')}
          totalPoints={questionScore}
        />}
        {page === 'admin' && isAdmin && <AdminPage
          title={adminTitle} description={adminDescription} start={adminStart} duration={adminDuration}
          questions={adminQuestions} busy={adminBusy} exams={exams} results={adminResults} profiles={profiles}
          onTitle={setAdminTitle} onDescription={setAdminDescription} onStart={setAdminStart} onDuration={setAdminDuration}
          onQuestionChange={(index, key, value) => setAdminQuestions((current) => current.map((q, i) => i === index ? { ...q, [key]: value } : q))}
          onCount={changeQuestionCount} onSubmit={createExam} onBack={() => setPage('dashboard')}
        />}
        {page === 'profile' && <ProfilePage profile={profile} email={session?.user.email || (isDemo ? demoUser.email : '')} exams={exams} />}
      </div>
      <footer className="footer"><span>آزمون‌یار</span><span>سامانه آزمون آنلاین فارسی</span><span>نسخه ۰٫۱</span></footer>
    </main>
    {notice && <div className="toast-wrap"><Notice notice={notice} onClose={() => setNotice(null)} /></div>}
  </div>
}

function Notice({ notice, onClose }: { notice: { type: 'success' | 'error' | 'info'; text: string }; onClose: () => void }) {
  return <div className={`notice ${notice.type}`}><span>{notice.text}</span><button onClick={onClose} aria-label="بستن پیام"><XCircle size={17} /></button></div>
}

function Dashboard({ exams, profile, now, onOpen, onAdmin, isAdmin, isDemo, onRefresh }: {
  exams: Exam[]; profile: Profile | null; now: number; onOpen: (exam: Exam) => void; onAdmin: () => void
  isAdmin: boolean; isDemo: boolean; onRefresh: () => void
}) {
  const active = exams.filter((e) => getStatus(e, now) === 'active')
  const upcoming = exams.filter((e) => getStatus(e, now) === 'upcoming')
  const ended = exams.filter((e) => getStatus(e, now) === 'ended')
  const [filter, setFilter] = useState<'all' | 'active' | 'upcoming' | 'ended'>('all')
  const visible = filter === 'all' ? exams : filter === 'active' ? active : filter === 'upcoming' ? upcoming : ended
  return <>
    <section className="welcome-row"><div><div className="eyebrow">فضای شخصی شما</div><h1>سلام، {profile?.full_name?.split(' ')[0] || 'خوش آمدید'} <span className="wave">✦</span></h1><p>از اینجا می‌توانید آزمون‌های خود را مشاهده و مدیریت کنید.</p></div><button className="button secondary refresh-button" onClick={onRefresh}><RefreshCw size={16} />به‌روزرسانی</button></section>
    {isDemo && <div className="demo-banner"><span className="demo-banner-icon"><BookOpen size={18} /></span><div><b>این یک پیش‌نمایش تعاملی است</b><span>اطلاعات نمونه‌اند و پس از اتصال Supabase، ثبت‌نام و ذخیره پاسخ‌ها واقعی می‌شوند.</span></div></div>}
    <section className="stats-grid">
      <StatCard icon={<ClipboardIcon />} label="کل آزمون‌ها" value={exams.length} hint="آزمون‌های منتشرشده" tone="purple" />
      <StatCard icon={<Clock3 size={20} />} label="در حال برگزاری" value={active.length} hint="قابل پاسخ‌دهی در حال حاضر" tone="green" />
      <StatCard icon={<BookOpen size={20} />} label="آزمون‌های پیش‌رو" value={upcoming.length} hint="زمان‌بندی‌شده" tone="blue" />
      <StatCard icon={<Award size={20} />} label="پایان‌یافته" value={ended.length} hint="آماده مشاهده نتیجه" tone="orange" />
    </section>
    <section className="section-block">
      <div className="section-heading"><div><h2>آزمون‌های من</h2><p>وضعیت و زمان‌بندی آزمون‌ها را دنبال کنید.</p></div>{isAdmin && <button className="button primary" onClick={onAdmin}><Plus size={17} />ساخت آزمون جدید</button>}</div>
      <div className="filter-tabs">
        {([['all', 'همه'], ['active', 'در حال برگزاری'], ['upcoming', 'پیش‌رو'], ['ended', 'پایان‌یافته']] as const).map(([value, label]) => <button key={value} className={filter === value ? 'filter-tab current' : 'filter-tab'} onClick={() => setFilter(value)}>{label}<span>{value === 'all' ? exams.length : value === 'active' ? active.length : value === 'upcoming' ? upcoming.length : ended.length}</span></button>)}
      </div>
      {visible.length === 0 ? <div className="empty-state"><div className="empty-icon"><BookOpen size={25} /></div><b>آزمونی در این بخش وجود ندارد</b><p>بعداً دوباره سر بزنید یا فیلتر دیگری را انتخاب کنید.</p></div> : <div className="exam-grid">{visible.map((exam) => <ExamCard key={exam.id} exam={exam} now={now} onOpen={() => onOpen(exam)} />)}</div>}
    </section>
    <section className="info-strip"><div className="info-icon"><ShieldCheck size={19} /></div><div><b>پاسخ‌هایتان محفوظ می‌مانند</b><p>پاسخ‌ها در طول آزمون به‌صورت خودکار ذخیره می‌شوند و پس از پایان زمان، امکان ویرایش آن‌ها بسته خواهد شد.</p></div><span className="info-decoration">01</span></section>
  </>
}

function ClipboardIcon() { return <BookOpen size={20} /> }
function StatCard({ icon, label, value, hint, tone }: { icon: ReactNode; label: string; value: number; hint: string; tone: string }) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-copy"><span>{label}</span><strong>{fa(value)}</strong><small>{hint}</small></div></div>
}
function ExamCard({ exam, now, onOpen }: { exam: Exam; now: number; onOpen: () => void }) {
  const status = getStatus(exam, now)
  const ended = status === 'ended'
  const active = status === 'active'
  return <article className="exam-card">
    <div className="exam-card-top"><div className={`exam-symbol ${active ? 'active' : ended ? 'ended' : ''}`}><BookOpen size={20} /></div><StatusBadge status={status} /></div>
    <h3>{exam.title}</h3><p className="exam-description">{exam.description || 'برای مشاهده جزئیات این آزمون وارد صفحه آن شوید.'}</p>
    <div className="exam-meta"><div><Clock3 size={15} /><span>{dateText(exam.starts_at)}</span></div><div><Users size={15} /><span>مدت آزمون: {fa(exam.duration_minutes)} دقیقه</span></div></div>
    <div className="exam-card-bottom"><span>{active ? `پایان: ${dateText(examEnd(exam).toISOString())}` : ended ? 'زمان آزمون به پایان رسیده' : 'شروع زمان‌بندی‌شده'}</span><button className={`button ${active ? 'primary' : 'soft'}`} onClick={onOpen}>{active ? 'ورود به آزمون' : ended ? 'مشاهده نتیجه' : 'جزئیات آزمون'}<ChevronLeft size={16} /></button></div>
  </article>
}
function StatusBadge({ status }: { status: 'upcoming' | 'active' | 'ended' }) {
  const map = { upcoming: ['upcoming', 'شروع نشده'], active: ['active', 'در حال برگزاری'], ended: ['ended', 'پایان‌یافته'] }
  return <span className={`status-badge ${map[status][0]}`}><i />{map[status][1]}</span>
}

function ExamPage({ exam, questions, answers, remainingSeconds, status, result, saving, demo, onAnswer, onBack, totalPoints }: {
  exam: Exam; questions: Question[]; answers: Record<number, string>; remainingSeconds: number
  status: 'upcoming' | 'active' | 'ended'; result: ExamResult | null; saving: boolean; demo: boolean
  onAnswer: (n: number, value: string) => void; onBack: () => void; totalPoints: number
}) {
  const progress = questions.length ? Object.values(answers).filter((v) => v.trim() && validNumber(v)).length : 0
  const ended = status === 'ended'
  return <>
    <div className="backline"><button className="back-button" onClick={onBack}><ArrowLeft size={17} />بازگشت به داشبورد</button><span className="muted small">صفحه آزمون</span></div>
    <div className="exam-heading-panel"><div><div className="eyebrow">آزمون آنلاین</div><h1>{exam.title}</h1><p>{exam.description || 'پاسخ هر سؤال را به‌صورت عددی وارد کنید.'}</p></div><StatusBadge status={status} /></div>
    <div className="exam-info-grid">
      <div className="exam-info-card"><span>زمان شروع</span><b>{dateText(exam.starts_at)}</b></div>
      <div className="exam-info-card"><span>مدت آزمون</span><b>{fa(exam.duration_minutes)} دقیقه</b></div>
      <div className="exam-info-card"><span>تعداد سؤال‌ها</span><b>{fa(questions.length || '—')}</b></div>
      <div className="exam-info-card"><span>مجموع نمره</span><b>{fa(totalPoints || '—')}</b></div>
    </div>
    {status === 'upcoming' && <div className="waiting-panel"><div className="waiting-icon"><Clock3 size={24} /></div><h2>آزمون هنوز شروع نشده است</h2><p>شروع آزمون برای زمان زیر برنامه‌ریزی شده است:</p><strong>{dateText(exam.starts_at)}</strong><span>صفحه را باز نگه دارید یا بعداً دوباره مراجعه کنید.</span></div>}
    {status === 'active' && <>
      <div className="timer-panel"><div className="timer-copy"><span>زمان باقی‌مانده</span><strong dir="ltr">{durationText(remainingSeconds)}</strong><small>پایان آزمون: {dateText(examEnd(exam).toISOString())}</small></div><div className="timer-progress"><div className="timer-progress-top"><span>پاسخ‌های ثبت‌شده</span><b>{fa(progress)} از {fa(questions.length)}</b></div><div className="progress-track"><i style={{ width: `${questions.length ? progress / questions.length * 100 : 0}%` }} /></div><div className="save-indicator">{saving ? <><span className="saving-dot" />در حال ذخیره پاسخ‌ها...</> : <><CheckCircle2 size={15} />ذخیره خودکار فعال است</>}</div></div></div>
      <div className="question-intro"><div><h2>پاسخ‌نامه</h2><p>برای هر سؤال فقط پاسخ عددی وارد کنید. صورت سؤال‌ها خارج از این سامانه ارائه می‌شوند.</p></div><span className="answer-count">{fa(questions.length)} سؤال</span></div>
      {questions.length === 0 ? <div className="empty-state"><div className="spinner" /><b>در حال دریافت فهرست سؤال‌ها...</b></div> : <div className="answer-grid">{questions.map((q) => <div className="answer-card" key={q.id}><div className="answer-card-head"><span className="question-number">{fa(q.question_number)}</span><div><b>سؤال {fa(q.question_number)}</b><small>{fa(q.points)} نمره</small></div><span className={answers[q.question_number]?.trim() ? 'answered-dot done' : 'answered-dot'} /></div><label className="answer-input-wrap"><span>پاسخ عددی</span><input inputMode="decimal" type="text" value={answers[q.question_number] ?? ''} onChange={(e) => onAnswer(q.question_number, e.target.value)} placeholder="عدد را وارد کنید" dir="ltr" /></label></div>)}</div>}
      <div className="exam-footnote"><ShieldCheck size={17} /><span>پاسخ‌ها به‌صورت خودکار ذخیره می‌شوند. تا پایان زمان می‌توانید آن‌ها را تغییر دهید.</span></div>
    </>}
    {ended && <div className="result-panel"><div className="result-icon"><Award size={29} /></div><div className="eyebrow">آزمون به پایان رسید</div><h2>{result ? 'نتیجه شما آماده است' : 'در حال تصحیح پاسخ‌ها'}</h2>{result ? <><div className="score-big"><strong>{fa(result.score)}</strong><span>از {fa(result.max_score)} نمره</span></div><div className="result-stats"><div><b>{fa(result.correct_count)}</b><span>پاسخ صحیح</span></div><div><b>{fa(Math.max(0, result.question_count - result.correct_count))}</b><span>پاسخ نادرست یا خالی</span></div><div><b>{fa(result.question_count)}</b><span>تعداد سؤال</span></div></div><p className="result-note">تصحیح بر اساس برابری دقیق عددی انجام شده است.</p></> : <p>برای این آزمون تلاشی ثبت نشده یا نتیجه هنوز آماده نیست. صفحه را کمی بعد به‌روزرسانی کنید.</p>}</div>}
    {demo && <div className="demo-note">این اطلاعات نمونه‌اند و در حالت نمایشی به دیتابیس ارسال نمی‌شوند.</div>}
  </>
}

function AdminPage({ title, description, start, duration, questions, busy, exams, results, profiles, onTitle, onDescription, onStart, onDuration, onQuestionChange, onCount, onSubmit, onBack }: {
  title: string; description: string; start: string; duration: string; questions: AdminQuestion[]; busy: boolean; exams: Exam[]
  results: ExamResult[]; profiles: Profile[]; onTitle: (v: string) => void; onDescription: (v: string) => void
  onStart: (v: string) => void; onDuration: (v: string) => void
  onQuestionChange: (i: number, key: keyof AdminQuestion, value: string) => void; onCount: (v: number) => void
  onSubmit: (e: FormEvent) => void; onBack: () => void
}) {
  const names = new Map(profiles.map((p) => [p.id, p.full_name] as const))
  return <>
    <div className="backline"><button className="back-button" onClick={onBack}><ArrowLeft size={17} />بازگشت به داشبورد</button><span className="muted small">فقط مدیر سامانه</span></div>
    <div className="page-title-row"><div><div className="eyebrow">پنل مدیریت</div><h1>مدیریت آزمون‌ها</h1><p>آزمون جدید بسازید و پاسخ‌نامه عددی را به‌صورت محرمانه ثبت کنید.</p></div><div className="admin-mark"><ShieldCheck size={24} /></div></div>
    <div className="admin-layout">
      <section className="panel-card create-panel"><div className="panel-title"><div><h2>ساخت آزمون جدید</h2><p>سؤال‌ها در این سایت نمایش داده نمی‌شوند.</p></div><span className="private-chip"><ShieldCheck size={14} />پاسخ‌نامه محرمانه</span></div>
        <form onSubmit={onSubmit} className="admin-form">
          <label className="field-label">عنوان آزمون<input value={title} onChange={(e) => onTitle(e.target.value)} placeholder="مثلاً آزمون مرحله اول" /></label>
          <label className="field-label">توضیحات کوتاه <small>(اختیاری)</small><textarea value={description} onChange={(e) => onDescription(e.target.value)} placeholder="توضیحات یا دستورالعمل آزمون" rows={2} /></label>
          <div className="form-row"><label className="field-label">زمان شروع<input type="datetime-local" value={start} onChange={(e) => onStart(e.target.value)} /></label><label className="field-label">مدت (دقیقه)<input type="number" min="1" max="600" value={duration} onChange={(e) => onDuration(e.target.value)} /></label></div>
          <div className="question-admin-heading"><div><b>پاسخ‌نامه</b><span>پاسخ صحیح هر سؤال و نمره آن را وارد کنید.</span></div><label className="count-picker">تعداد سؤال <input type="number" min="1" max="100" value={questions.length} onChange={(e) => onCount(Number(e.target.value))} /></label></div>
          <div className="key-table"><div className="key-table-head"><span>شماره</span><span>پاسخ صحیح</span><span>نمره</span></div>{questions.map((q, i) => <div className="key-table-row" key={i}><b>{fa(i + 1)}</b><input aria-label={`پاسخ سؤال ${i + 1}`} inputMode="decimal" value={q.answer} onChange={(e) => onQuestionChange(i, 'answer', e.target.value)} placeholder="عدد" dir="ltr" /><input aria-label={`نمره سؤال ${i + 1}`} type="number" min="0.001" step="0.001" value={q.points} onChange={(e) => onQuestionChange(i, 'points', e.target.value)} dir="ltr" /></div>)}</div>
          <div className="admin-warning"><ShieldCheck size={17} /><span>پاسخ‌نامه در جدول جداگانه و با دسترسی مدیر ذخیره می‌شود؛ شرکت‌کنندگان به آن دسترسی ندارند.</span></div>
          <button className="button primary full" type="submit" disabled={busy}>{busy ? 'در حال ساخت آزمون...' : 'ساخت و انتشار آزمون'}<Plus size={17} /></button>
        </form>
      </section>
      <aside className="admin-side">
        <div className="panel-card admin-summary"><div className="summary-icon"><BookOpen size={20} /></div><b>{fa(exams.length)} آزمون ثبت‌شده</b><span>آزمون‌های منتشرشده در سامانه</span></div>
        <div className="panel-card"><div className="panel-title compact"><div><h2>آخرین نتایج</h2><p>نتایج آزمون‌های تصحیح‌شده</p></div></div>{results.length === 0 ? <div className="mini-empty">هنوز نتیجه‌ای ثبت نشده است.</div> : <div className="result-list">{results.slice(0, 8).map((r) => <div className="result-row" key={r.id}><div className="avatar tiny">{(names.get(r.user_id) || 'ک').slice(0, 1)}</div><div className="result-user"><b>{names.get(r.user_id) || r.user_id.slice(0, 8)}</b><span>{fa(r.correct_count)} پاسخ صحیح</span></div><strong>{fa(r.score)}<small> / {fa(r.max_score)}</small></strong></div>)}</div>}</div>
      </aside>
    </div>
  </>
}

function ProfilePage({ profile, email, exams }: { profile: Profile | null; email: string; exams: Exam[] }) {
  return <>
    <div className="page-title-row"><div><div className="eyebrow">حساب کاربری</div><h1>پروفایل من</h1><p>اطلاعات حساب و وضعیت حضور شما در سامانه.</p></div></div>
    <div className="profile-card panel-card"><div className="profile-avatar">{(profile?.full_name || 'ک').slice(0, 1)}</div><div className="profile-data"><h2>{profile?.full_name || 'کاربر'}</h2><p>{email}</p><span className="role-pill">{profile?.role === 'admin' ? 'مدیر سامانه' : 'شرکت‌کننده'}</span></div></div>
    <div className="stats-grid profile-stats"><StatCard icon={<BookOpen size={20} />} label="آزمون‌های قابل مشاهده" value={exams.length} hint="در حساب شما" tone="purple" /><StatCard icon={<ShieldCheck size={20} />} label="وضعیت حساب" value={1} hint="حساب فعال" tone="green" /></div>
    <div className="profile-tip"><ShieldCheck size={18} /><span>برای امنیت حساب، رمز عبور خود را در اختیار دیگران قرار ندهید.</span></div>
  </>
}
