-- Run only after the intended user has registered and their profile row exists.
-- Replace the email address, then verify that exactly one row was updated.
update public.profiles
set role = 'admin'
where id = (
  select id
  from auth.users
  where email = lower('admin@example.com')
);
