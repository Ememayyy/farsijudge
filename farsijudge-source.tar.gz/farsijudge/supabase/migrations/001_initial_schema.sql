-- FarsiJudge initial schema
-- Run in Supabase Dashboard -> SQL Editor.
-- All security-definer functions pin an empty search_path and schema-qualify objects.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default 'کاربر جدید',
  role text not null default 'participant' check (role in ('participant', 'admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.exams (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  starts_at timestamptz not null,
  duration_minutes integer not null default 120 check (duration_minutes between 1 and 600),
  is_published boolean not null default false,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);

-- This table exposes only question numbers and points, never question statements or answers.
create table if not exists public.exam_questions (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  question_number integer not null check (question_number between 1 and 300),
  points numeric(12, 3) not null default 1 check (points > 0),
  unique (exam_id, question_number)
);

-- The answer key is separate and readable only by admins.
create table if not exists public.exam_answer_keys (
  exam_id uuid not null references public.exams(id) on delete cascade,
  question_number integer not null,
  correct_answer numeric not null,
  primary key (exam_id, question_number),
  foreign key (exam_id, question_number)
    references public.exam_questions(exam_id, question_number) on delete cascade
);

-- An attempt is created when a participant opens an active exam. It also lets us grade 0-answer attempts.
create table if not exists public.exam_attempts (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  started_at timestamptz not null default now(),
  unique (exam_id, user_id)
);

create table if not exists public.exam_answers (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  question_number integer not null,
  answer numeric not null,
  updated_at timestamptz not null default now(),
  unique (exam_id, user_id, question_number),
  foreign key (exam_id, question_number)
    references public.exam_questions(exam_id, question_number) on delete cascade
);

create table if not exists public.exam_results (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  score numeric(14, 3) not null default 0,
  max_score numeric(14, 3) not null default 0,
  correct_count integer not null default 0,
  question_count integer not null default 0,
  graded_at timestamptz not null default now(),
  unique (exam_id, user_id)
);

create index if not exists exams_starts_at_idx on public.exams(starts_at);
create index if not exists exam_attempts_exam_user_idx on public.exam_attempts(exam_id, user_id);
create index if not exists exam_answers_exam_user_idx on public.exam_answers(exam_id, user_id);
create index if not exists exam_results_user_idx on public.exam_results(user_id, graded_at desc);

-- Create a profile automatically after a successful Supabase Auth registration.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), 'کاربر جدید')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Role is stored in a protected table, never in user-editable auth metadata.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and p.role = 'admin'
  );
$$;

revoke all on function public.is_admin() from public, anon;
grant execute on function public.is_admin() to authenticated;

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = pg_catalog.now();
  return new;
end;
$$;

drop trigger if exists touch_exam_answers_updated_at on public.exam_answers;
create trigger touch_exam_answers_updated_at
  before update on public.exam_answers
  for each row execute procedure public.touch_updated_at();

-- Enable RLS on every table in the exposed public schema.
alter table public.profiles enable row level security;
alter table public.exams enable row level security;
alter table public.exam_questions enable row level security;
alter table public.exam_answer_keys enable row level security;
alter table public.exam_attempts enable row level security;
alter table public.exam_answers enable row level security;
alter table public.exam_results enable row level security;

-- Explicit grants: the policies below further restrict which rows each user can access.
revoke all on public.profiles from anon, authenticated;
revoke all on public.exams from anon, authenticated;
revoke all on public.exam_questions from anon, authenticated;
revoke all on public.exam_answer_keys from anon, authenticated;
revoke all on public.exam_attempts from anon, authenticated;
revoke all on public.exam_answers from anon, authenticated;
revoke all on public.exam_results from anon, authenticated;

grant select on public.profiles to authenticated;
grant update (full_name) on public.profiles to authenticated;
grant select, insert, update, delete on public.exams to authenticated;
grant select, insert, update, delete on public.exam_questions to authenticated;
grant select, insert, update, delete on public.exam_answer_keys to authenticated;
grant select on public.exam_attempts to authenticated;
grant select, insert, update, delete on public.exam_answers to authenticated;
grant select on public.exam_results to authenticated;

-- Profiles: users see their own profile; admins can view all profiles.
drop policy if exists "profiles_read_self_or_admin" on public.profiles;
create policy "profiles_read_self_or_admin"
on public.profiles for select to authenticated
using ((select auth.uid()) = id or (select public.is_admin()));

drop policy if exists "profiles_update_own_name" on public.profiles;
create policy "profiles_update_own_name"
on public.profiles for update to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

-- Exams: published exam information is visible to signed-in users; only admins manage exams.
drop policy if exists "exams_read_published_or_admin" on public.exams;
create policy "exams_read_published_or_admin"
on public.exams for select to authenticated
using (is_published or (select public.is_admin()));

drop policy if exists "exams_admin_insert" on public.exams;
create policy "exams_admin_insert"
on public.exams for insert to authenticated
with check ((select public.is_admin()) and created_by = (select auth.uid()));

drop policy if exists "exams_admin_update" on public.exams;
create policy "exams_admin_update"
on public.exams for update to authenticated
using ((select public.is_admin()))
with check ((select public.is_admin()));

drop policy if exists "exams_admin_delete" on public.exams;
create policy "exams_admin_delete"
on public.exams for delete to authenticated
using ((select public.is_admin()));

-- Participants see the number and points of questions, not the question text or answer key.
drop policy if exists "questions_read_published_or_admin" on public.exam_questions;
create policy "questions_read_published_or_admin"
on public.exam_questions for select to authenticated
using (
  exists (
    select 1 from public.exams e
    where e.id = exam_id and (e.is_published or (select public.is_admin()))
  )
);

drop policy if exists "questions_admin_insert" on public.exam_questions;
create policy "questions_admin_insert"
on public.exam_questions for insert to authenticated
with check ((select public.is_admin()));

drop policy if exists "questions_admin_update" on public.exam_questions;
create policy "questions_admin_update"
on public.exam_questions for update to authenticated
using ((select public.is_admin()))
with check ((select public.is_admin()));

drop policy if exists "questions_admin_delete" on public.exam_questions;
create policy "questions_admin_delete"
on public.exam_questions for delete to authenticated
using ((select public.is_admin()));

-- Answer key: admins only, through RLS and table grants.
drop policy if exists "answer_keys_admin_only" on public.exam_answer_keys;
create policy "answer_keys_admin_only"
on public.exam_answer_keys for all to authenticated
using ((select public.is_admin()))
with check ((select public.is_admin()));

-- A participant can read only their own attempts. Attempts are created only by start_exam().
drop policy if exists "attempts_read_own_or_admin" on public.exam_attempts;
create policy "attempts_read_own_or_admin"
on public.exam_attempts for select to authenticated
using (user_id = (select auth.uid()) or (select public.is_admin()));

-- Answers: users can read their own answers and modify them only while the scheduled exam is active.
drop policy if exists "answers_read_own_or_admin" on public.exam_answers;
create policy "answers_read_own_or_admin"
on public.exam_answers for select to authenticated
using (user_id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists "answers_insert_during_exam" on public.exam_answers;
create policy "answers_insert_during_exam"
on public.exam_answers for insert to authenticated
with check (
  user_id = (select auth.uid())
  and exists (
    select 1 from public.exam_attempts a
    where a.exam_id = exam_answers.exam_id and a.user_id = (select auth.uid())
  )
  and exists (
    select 1 from public.exams e
    where e.id = exam_answers.exam_id
      and e.is_published
      and pg_catalog.now() >= e.starts_at
      and pg_catalog.now() < e.starts_at + pg_catalog.make_interval(mins => e.duration_minutes)
  )
);

drop policy if exists "answers_update_during_exam" on public.exam_answers;
create policy "answers_update_during_exam"
on public.exam_answers for update to authenticated
using (
  user_id = (select auth.uid())
  and exists (
    select 1 from public.exams e
    where e.id = exam_answers.exam_id
      and e.is_published
      and pg_catalog.now() >= e.starts_at
      and pg_catalog.now() < e.starts_at + pg_catalog.make_interval(mins => e.duration_minutes)
  )
)
with check (
  user_id = (select auth.uid())
  and exists (
    select 1 from public.exam_attempts a
    where a.exam_id = exam_answers.exam_id and a.user_id = (select auth.uid())
  )
  and exists (
    select 1 from public.exams e
    where e.id = exam_answers.exam_id
      and e.is_published
      and pg_catalog.now() >= e.starts_at
      and pg_catalog.now() < e.starts_at + pg_catalog.make_interval(mins => e.duration_minutes)
  )
);

drop policy if exists "answers_delete_during_exam" on public.exam_answers;
create policy "answers_delete_during_exam"
on public.exam_answers for delete to authenticated
using (
  user_id = (select auth.uid())
  and exists (
    select 1 from public.exams e
    where e.id = exam_answers.exam_id
      and e.is_published
      and pg_catalog.now() >= e.starts_at
      and pg_catalog.now() < e.starts_at + pg_catalog.make_interval(mins => e.duration_minutes)
  )
);

-- Participants see their result only after the scheduled end; admins can see all results.
drop policy if exists "results_read_after_end" on public.exam_results;
create policy "results_read_after_end"
on public.exam_results for select to authenticated
using (
  (select public.is_admin())
  or (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.exams e
      where e.id = exam_results.exam_id
        and pg_catalog.now() >= e.starts_at + pg_catalog.make_interval(mins => e.duration_minutes)
    )
  )
);

-- Server clock endpoint used for the countdown UI. DB-side policies remain authoritative.
create or replace function public.server_time()
returns timestamptz
language sql
stable
set search_path = ''
as $$ select pg_catalog.now(); $$;
revoke all on function public.server_time() from public, anon;
grant execute on function public.server_time() to authenticated;

-- Starts (or resumes) a participant's single attempt. Start time is fixed by the exam schedule.
create or replace function public.start_exam(p_exam_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is null then
    raise exception 'ورود به حساب کاربری الزامی است.';
  end if;
  if not exists (
    select 1 from public.exams e
    where e.id = p_exam_id
      and e.is_published
      and pg_catalog.now() >= e.starts_at
      and pg_catalog.now() < e.starts_at + pg_catalog.make_interval(mins => e.duration_minutes)
  ) then
    raise exception 'این آزمون در حال حاضر فعال نیست.';
  end if;
  insert into public.exam_attempts (exam_id, user_id)
  values (p_exam_id, (select auth.uid()))
  on conflict (exam_id, user_id) do nothing;
end;
$$;
revoke all on function public.start_exam(uuid) from public, anon;
grant execute on function public.start_exam(uuid) to authenticated;

-- Admin-only atomic exam creation: metadata, question numbers, and answer key are saved together.
create or replace function public.create_exam_with_answer_key(
  p_title text,
  p_description text,
  p_starts_at timestamptz,
  p_duration_minutes integer,
  p_questions jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_exam_id uuid;
  v_item jsonb;
  v_question_number integer;
  v_points numeric;
  v_correct_answer numeric;
begin
  if not (select public.is_admin()) then
    raise exception 'فقط مدیر سایت می‌تواند آزمون بسازد.';
  end if;
  if nullif(trim(p_title), '') is null then
    raise exception 'عنوان آزمون الزامی است.';
  end if;
  if p_starts_at is null or p_starts_at <= pg_catalog.now() then
    raise exception 'زمان شروع باید در آینده باشد.';
  end if;
  if p_duration_minutes is null or p_duration_minutes < 1 or p_duration_minutes > 600 then
    raise exception 'مدت آزمون باید بین ۱ تا ۶۰۰ دقیقه باشد.';
  end if;
  if pg_catalog.jsonb_typeof(p_questions) <> 'array' or pg_catalog.jsonb_array_length(p_questions) < 1 then
    raise exception 'آزمون باید حداقل یک سؤال داشته باشد.';
  end if;

  insert into public.exams (title, description, starts_at, duration_minutes, is_published, created_by)
  values (trim(p_title), coalesce(p_description, ''), p_starts_at, p_duration_minutes, true, (select auth.uid()))
  returning id into v_exam_id;

  for v_item in select value from pg_catalog.jsonb_array_elements(p_questions)
  loop
    v_question_number := (v_item ->> 'question_number')::integer;
    v_points := (v_item ->> 'points')::numeric;
    v_correct_answer := (v_item ->> 'correct_answer')::numeric;
    if v_question_number < 1 or v_question_number > 300 or v_points <= 0 then
      raise exception 'شماره سؤال یا نمره آن نامعتبر است.';
    end if;
    insert into public.exam_questions (exam_id, question_number, points)
    values (v_exam_id, v_question_number, v_points);
    insert into public.exam_answer_keys (exam_id, question_number, correct_answer)
    values (v_exam_id, v_question_number, v_correct_answer);
  end loop;

  return v_exam_id;
end;
$$;
revoke all on function public.create_exam_with_answer_key(text, text, timestamptz, integer, jsonb) from public, anon;
grant execute on function public.create_exam_with_answer_key(text, text, timestamptz, integer, jsonb) to authenticated;

-- Internal grading uses PostgreSQL NUMERIC equality, avoiding JS floating-point behavior.
create or replace function public.finalize_exam_internal(p_exam_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not exists (
    select 1 from public.exams e
    where e.id = p_exam_id
      and e.is_published
      and pg_catalog.now() >= e.starts_at + pg_catalog.make_interval(mins => e.duration_minutes)
  ) then
    return;
  end if;

  with participants as (
    select distinct a.user_id
    from public.exam_attempts a
    where a.exam_id = p_exam_id
  )
  insert into public.exam_results (
    exam_id, user_id, score, max_score, correct_count, question_count, graded_at
  )
  select
    p_exam_id,
    p.user_id,
    coalesce(sum(case when a.answer = k.correct_answer then q.points else 0 end), 0),
    coalesce(sum(q.points), 0),
    count(*) filter (where a.answer = k.correct_answer)::integer,
    count(*)::integer,
    pg_catalog.now()
  from participants p
  cross join public.exam_questions q
  left join public.exam_answers a
    on a.exam_id = p_exam_id
   and a.user_id = p.user_id
   and a.question_number = q.question_number
  left join public.exam_answer_keys k
    on k.exam_id = p_exam_id
   and k.question_number = q.question_number
  where q.exam_id = p_exam_id
  group by p.user_id
  on conflict (exam_id, user_id) do nothing;
end;
$$;
revoke all on function public.finalize_exam_internal(uuid) from public, anon, authenticated;

-- Safe public entry point: a signed-in user can trigger grading only after the deadline.
create or replace function public.finalize_exam(p_exam_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is null then
    raise exception 'ورود به حساب کاربری الزامی است.';
  end if;
  if not exists (
    select 1 from public.exams e
    where e.id = p_exam_id and e.is_published
      and pg_catalog.now() >= e.starts_at + pg_catalog.make_interval(mins => e.duration_minutes)
  ) then
    raise exception 'زمان این آزمون هنوز به پایان نرسیده است.';
  end if;
  perform public.finalize_exam_internal(p_exam_id);
end;
$$;
revoke all on function public.finalize_exam(uuid) from public, anon;
grant execute on function public.finalize_exam(uuid) to authenticated;

-- Optional Cron target: call once a minute to grade even when nobody is online.
create or replace function public.finalize_all_expired_exams()
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_exam_id uuid;
begin
  for v_exam_id in
    select e.id from public.exams e
    where e.is_published
      and pg_catalog.now() >= e.starts_at + pg_catalog.make_interval(mins => e.duration_minutes)
      and exists (select 1 from public.exam_attempts a where a.exam_id = e.id)
      and exists (
        select 1 from public.exam_attempts a
        left join public.exam_results r on r.exam_id = a.exam_id and r.user_id = a.user_id
        where a.exam_id = e.id and r.id is null
      )
  loop
    perform public.finalize_exam_internal(v_exam_id);
  end loop;
end;
$$;
revoke all on function public.finalize_all_expired_exams() from public, anon, authenticated;
