-- Optional: enable Supabase Cron (pg_cron) first in Dashboard -> Integrations -> Cron.
-- Then run this file once in the SQL Editor. The job grades attempts even when nobody is online.
-- It only processes exams that have ended and still have at least one ungraded attempt.

select cron.schedule(
  'farsijudge-grade-ended-exams',
  '* * * * *',
  'select public.finalize_all_expired_exams();'
);

-- Check the scheduled job:
-- select jobid, jobname, schedule from cron.job where jobname = 'farsijudge-grade-ended-exams';
-- Remove it if needed:
-- select cron.unschedule('farsijudge-grade-ended-exams');
